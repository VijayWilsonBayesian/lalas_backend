const express = require("express");
const { getDatabasePool } = require("../db");
const router = express.Router();


// addons dashboard admin_addon
router.post("/addFoodItem", async (req, res) => {
    try {
      const tempPool = getDatabasePool();
  
      const { name, imageUrl, vegType, type, ingredient, price, status, qty } = req.body;
  
      try {
        const result = await tempPool.query(
          `
          INSERT INTO admin_addon (name, image_url, veg_type, type, ingredient, price, status, qty)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
          RETURNING *;
          `,
          [name, imageUrl, vegType, type, ingredient, price, status, qty]
        );
  
        const foodItem = result.rows[0];
  
        res.json({ status: true, message: "Food item added successfully", foodItem });
      } catch (error) {
        console.log("Error adding food item:", error);
        res.status(500).json({ status: false, error: "Internal Server Error" });
      }
    } catch (error) {
      console.log("Error creating pool:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  });
  
  // addons dashboard delete
  
  router.delete('/deleteFoodItem/:id', async (req, res) => {
    const { id } = req.params;
    const tempPool = getDatabasePool();
    try {
      const query = 'DELETE FROM admin_addon WHERE id = $1';
      const result = await tempPool.query(query, [id]);
      if (result.rowCount === 1) {
        res.status(200).json({ message: 'Item deleted successfully' });
      } else {
        res.status(404).json({ message: 'Item not found' });
      }
    } catch (error) {
      console.error('Error deleting food item:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  
  
  // show addons Mainapp
  router.get("/getfoodItems", async (req, res) => {
    try {
      const tempPool = getDatabasePool();
  
      const getFoodItemsQuery = 'SELECT * FROM admin_addon';
  
      const result = await tempPool.query(getFoodItemsQuery);
  
      res.json(result.rows);
    } catch (error) {
      console.error('Error retrieving food items:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  
  
  router.put("/increment/:id", async (req, res) => {
    const { id } = req.params;
    const tempPool = getDatabasePool();
    try {
      const result = await tempPool.query(
        'UPDATE admin_addon SET qty = qty + 1 WHERE id = $1 RETURNING qty',
        [id]
      );
      if (result.rowCount === 1) {
        const updatedQty = result.rows[0].qty;
        res.status(200).json({ message: 'Quantity incremented successfully', qty: updatedQty });
      } else {
        res.status(404).json({ message: 'Item not found' });
      }
    } catch (error) {
      console.error('Error incrementing quantity:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  
  router.put("/decrement/:id", async (req, res) => {
    const { id } = req.params;
    const tempPool = getDatabasePool();
    try {
      const result = await tempPool.query(
        'UPDATE admin_addon SET qty = qty - 1 WHERE id = $1 AND qty > 0 RETURNING qty',
        [id]
      );
      if (result.rowCount === 1) {
        const updatedQty = result.rows[0].qty;
        res.status(200).json({ message: 'Quantity decremented successfully', qty: updatedQty });
      } else {
        res.status(404).json({ message: 'Item not found or quantity already zero' });
      }
    } catch (error) {
      console.error('Error decrementing quantity:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  module.exports = router;