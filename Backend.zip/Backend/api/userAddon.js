const express = require("express");
const { getDatabasePool } = require("../db");

const router = express.Router();

router.post("/userAddon", async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const { orderId, status, uid, currentTime, totalPricePaid, paymentMethod, types, userdata, qty, subTotal, gst, deliveryCharge } = req.body;

    try {
      const typesJSONB = JSON.stringify(types);
      const userdataJSONB = JSON.stringify(userdata); 

      const result = await tempPool.query(
        `
        INSERT INTO addon (orderId, status, uid, currentTime, totalPricePaid, paymentMethod, types, userdata, qty, subTotal, gst, deliveryCharge)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        RETURNING *;
        `,
        [orderId, status, uid, currentTime, totalPricePaid, paymentMethod, typesJSONB, userdataJSONB, qty, subTotal, gst, deliveryCharge]
      );

      const addon = result.rows[0];

      res.json({ status: true, message: "Addon added successfully", addon });
    } catch (error) {
      if (error.code === '23505' && error.constraint === 'addon_pkey') {
        return res.status(400).json({ status: false, message: "Order ID already exists" });
      }
      
      console.log("Error adding addon:", error);
      res.status(500).json({ status: false, message: "Internal Server Error" });
    }
  } catch (error) {
    console.log("Error creating pool:", error);
    res.status(500).json({ status: false, message: "Internal Server Error" });
  }
});


router.get("/userAddon", async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const getAddonQuery = 'SELECT * FROM addon';

    const result = await tempPool.query(getAddonQuery);

    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving addon data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

router.put('/userAddon/:orderId', async (req, res) => {
  const { orderId } = req.params;
  const { status } = req.body;

  const tempPool = getDatabasePool();

  const updateStatusQuery = `
    UPDATE addon
    SET status = $1
    WHERE orderId = $2
  `;

  try {
    await tempPool.query(updateStatusQuery, [status, orderId]);
    res.status(200).json({ message: 'Status updated successfully', status });

  } catch (error) {
    console.error('Error updating status:', error);
    res.status(500).json({ error: 'Internal server error' });
  } finally {
    await tempPool.end();
  }
});


router.post('/getAddonData', async (req, res) => {
  const { uid } = req.body;
  const tempPool = getDatabasePool();

  try {
    const query = {
      text: 'SELECT * FROM addon WHERE uid = $1',
      values: [uid],
    };

    const result = await tempPool.query(query);

    // Send the fetched data as response
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching addon data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


module.exports = router;
