const express = require("express");
// const { Pool } = require("pg");
const app = express();
app.use(express.json());
app.use('/image', express.static('image'));
const multer = require('multer');
const cors = require('cors');
const https = require('https');
const fs = require('fs');
const validateAPIKey = require("./api/apikeyMiddleware");

// Load SSL certificate and key
const privateKey = fs.readFileSync('./cert/key.pem', 'utf8');
const certificate = fs.readFileSync('./cert/cert.pem', 'utf8');

const credentials = { key: privateKey, cert: certificate };

// Create HTTPS server
const httpsServer = https.createServer(credentials, app);

const userAddonRouter = require("./api/userAddon");
const adminAddonRouter = require("./api/adminAddon");
const deliveryRouter = require("./api/delivery");
const menuRouter = require("./api/WeeklyMenu");
const serviceRouter = require("./api/playstoreUpdate")
const setupMeals = require("./api/setupMeals")
const main = require("./api/Main")
// twilio
const bodyParser = require("body-parser");
const twilio = require("twilio");
app.use(cors());

const {
  createDatabase,
  getDatabasePool,
  createTable,
  createSetupMealsTable,
  createImagesTable,
  createFoodItemsTable,
  createAddonTable,
  createDeliveryTable,
  createDeliverCompleteyTable,
  createMenuTable,
  createDeleteUserTable,
  createUpdatePushTable,
  createRoutesTableAndInsertData,
  createMealPricesTable,
} = require("./db");



// Routes
app.use("/", userAddonRouter);
app.use("/", adminAddonRouter);
app.use("/",deliveryRouter);
app.use("/",menuRouter);
app.use("/",serviceRouter);
app.use("/",setupMeals);
app.use("/",main);


// Saved images

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './image'); 
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); 
  },
});

const upload = multer({
  storage: multer.memoryStorage(), 
});

// upload image dashboard

app.post("/uploadImage", upload.single('image'), async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    if (!req.file) {
      return res.status(400).json({ status: false, error: "No image file provided" });
    }

    const imageBuffer = req.file.buffer;

    const imageUrl = `https://lalaskitchen.in:3000/image/${req.file.originalname}`;

    try {
      const existingImage = await tempPool.query(
        "SELECT * FROM images WHERE image_url = $1",
        [imageUrl]
      );

      if (existingImage.rows.length > 0) {
        return res.json({ status: false, message: "Image with the same name already exists" });
      }
      const fs = require('fs');
      const imagePath = `./image/${req.file.originalname}`;
      fs.writeFileSync(imagePath, imageBuffer);

      const result = await tempPool.query(
        "INSERT INTO images (image_url) VALUES ($1) RETURNING *",
        [imageUrl]
      );

      const image = result.rows[0];

      res.json({ status: true, message: "Image uploaded successfully", image });
    } catch (error) {
      console.log("Error saving image URL to the database:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.log("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
});

// get image dashboard
app.get("/listImages", async (req, res) => {
  try {
    const tempPool = getDatabasePool();

    const getImagesQuery = 'SELECT id, image_url FROM images';

    const result = await tempPool.query(getImagesQuery);
    res.json(result.rows);
  } catch (error) {
    console.error('Error retrieving images:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// image status update dashboard
app.post('/addons/:id', async (req, res) => {
  const addonId = req.params.id;
  const newStatus = req.body.status;
  const tempPool = getDatabasePool();
  try {
    const updateAddonStatusQuery = `
      UPDATE admin_addon
      SET status = $1
      WHERE id = $2
    `;
    await tempPool.query(updateAddonStatusQuery, [newStatus, addonId]);
    res.status(200).json({ message: ' status updated successfully' });
  } catch (error) {
    console.error('Error updating  status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// delete image dashboard
app.delete("/deleteImage/:id", async (req, res) => {
  try {
    const tempPool = getDatabasePool();
    const { id } = req.params;

    try {
      const result = await tempPool.query("SELECT * FROM images WHERE id = $1", [id]);

      if (result.rows.length === 0) {
        return res.json({ status: false, message: "Image not found" });
      }

      await tempPool.query("DELETE FROM images WHERE id = $1", [id]);

      const fs = require('fs');
      const imagePath = `./image/${result.rows[0].image_url.split('/').pop()}`;
      fs.unlinkSync(imagePath);

      res.json({ status: true, message: "Image deleted successfully" });
    } catch (error) {
      console.error("Error deleting image:", error);
      res.status(500).json({ status: false, error: "Internal Server Error" });
    }
  } catch (error) {
    console.error("Error creating pool:", error);
    res.status(500).json({ status: false, error: "Internal Server Error" });
  }
})





// Twilio credentials
// const accountSid = "ACb3077f569065a1509ae5dc32376378d3";
// const authToken = "a5f0c7f72ad25f0377e6a0fb148dff15";
// const verifySid = "VA63e65af0af250cf4a40139f3acf4a697";

const accountSid = "AC7d2346a846d711122a7bcbd95ce407a1";
const authToken = "3c210c09f06f4422b66057d953386c14";
const verifySid = "VA4c39d32a9d98f134cc1f50e973c45f83";
const twilioClient = new twilio(accountSid, authToken);

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Generate OTP
function generateOTP() {
  return Math.floor(1000 + Math.random() * 9000).toString();
}

const otpStorage = {};
const otpTimers = {};

// Send OTP via WhatsApp
app.post('/send-otp', validateAPIKey, async (req, res) => {
  const { to } = req.body;

  if (!to) {
    return res.status(400).json({ error: 'Missing phone number' });
  }

  const currentTime = Date.now();
  const otpDetails = otpStorage[to];

  // Check if OTP was sent within the last 30 minutes
  if (otpDetails && (currentTime - otpDetails.timestamp) < 15 * 60 * 1000) {
    return res.status(429).json({ message: 'OTP already sent. Please try again after 15 minutes.' });
  }


  // if (otpDetails && (currentTime - otpDetails.timestamp) < 30 * 60 * 1000) {
  //   return res.status(429).json({ message: 'OTP already sent. Please try again after 30 minutes.' });
  // }
  const otp = generateOTP();
  otpStorage[to] = { otp, timestamp: currentTime };

  // Clear the previous timeout 
  if (otpTimers[to]) {
    clearTimeout(otpTimers[to]);
  }

  // Set a timeout to delete the OTP after 30 minutes

  otpTimers[to] = setTimeout(() => {
    delete otpStorage[to];
    delete otpTimers[to];
  }, 15 * 60 * 1000);

  // otpTimers[to] = setTimeout(() => {
  //   delete otpStorage[to];
  //   delete otpTimers[to];
  // }, 30 * 60 * 1000);


  try {
    await twilioClient.verify.services(verifySid)
      .verifications
      .create({
        to: `+${to}`,
        channel: 'sms',
        code: otp
      });

    return res.status(200).json({ success: true, message: 'OTP sent successfully' });
  } catch (error) {
    console.error(error);

    if (error.code === 60410) {
      return res.status(403).json({ message: 'The destination phone number has been temporarily blocked by Twilio due to fraudulent activities. Please contact support or use a different phone number.' });
    }

    return res.status(500).json({ message: 'Failed to send OTP' });
  }
});



// Verify OTP
app.post('/verify-otp', validateAPIKey ,async (req, res) => {
  const { to, otp } = req.body;

  if (!to || !otp) {
    return res.status(400).json({ message: 'Missing phone number or OTP' });
  }

  try {
    const verificationCheck = await twilioClient.verify.services(verifySid)
      .verificationChecks
      .create({
        // to: `whatsapp:${to}`,
        to: `+${to}`,
        code: otp
      });

    if (verificationCheck.status === 'approved') {
      return res.status(200).json({ success: true, message: 'OTP verified successfully' });
    } else {
      return res.status(400).json({ message: 'Invalid OTP' });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Failed to verify OTP' });
  }
});


//Create db 


createDatabase().then(() => createTable())
  .then(() => createSetupMealsTable())
  .then(() => createImagesTable()) 
  .then(() => createFoodItemsTable()) 
  .then(() => createAddonTable()) 
  .then(() => createDeliveryTable()) 
  .then(() => createDeliverCompleteyTable()) 
  .then(() => createMenuTable()) 
  .then(() => createDeleteUserTable()) 
  .then(() => createUpdatePushTable()) 
  .then(() => createRoutesTableAndInsertData()) 
  .then(() => createMealPricesTable()) 
  .then(() => {

    const PORT = process.env.PORT || 3000;

    // app.listen(PORT, () => {
    //   console.log(`Http Server is running on port ${PORT}`);
    // });

// Start HTTPS

    httpsServer.listen(PORT, () => {
      console.log(`Https Server is running on port ${PORT}`);
    });
    
    
  }).catch((error) => console.error("Error initializing:", error));




// Run api


// const PORT = process.env.PORT || 3000;



// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });

    // httpsServer.listen(PORT, () => {
    //   console.log(`Https Server is running on port ${PORT}`);
    // });

  // Total 44 api