const { Pool } = require("pg");
const config = require("./config");

// Database creation function
const createDatabase = async () => {
  const tempPool = new Pool({
    user: config.database.user,
    host: config.database.host,
    database: "postgres",
    password: config.database.password,
    port: config.database.port,
  });

  try {
    await tempPool.query("CREATE DATABASE lalas");
    console.log("Database created successfully");
  } catch (error) {
    if (error.code === "42P04") {
      console.log("Database already exists");
    } else {
      console.error("Error creating database:", error);
      process.exit(-1);
    }
  } finally {
    await tempPool.end();
  }
};

const getDatabasePool = () => {
  return new Pool({
    user: config.database.user,
    host: config.database.host,
    database: config.database.name,
    password: config.database.password,
    port: config.database.port,
  });
};

// Table creation function
const createTable = async () => {
  const tempPool = getDatabasePool();

  const createUserTableQuery = `
      CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY,
        first_name VARCHAR(100),
        last_name VARCHAR(100),
        phone_number VARCHAR(15) UNIQUE,
        created_at TIMESTAMP,
        house_name VARCHAR(100),
        road_and_location VARCHAR(255),
        area VARCHAR(255),
        locality VARCHAR(255),
        route VARCHAR(255),
        jwt_token VARCHAR(255),
        user_info VARCHAR(20),
        uid VARCHAR(100),
        FirebaseToken VARCHAR(255),
        loginstatus BOOLEAN DEFAULT false
      );
    `;

  try {
    await tempPool.query(createUserTableQuery);
    console.log("Users table created successfully");
  } catch (error) {
    console.log("Error creating users table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};
// Table creation function
const createSetupMealsTable = async () => {
  const tempPool = getDatabasePool();

  const createSetupMealsTableQuery = `
      CREATE TABLE IF NOT EXISTS setupmeals (
        orderId VARCHAR(50) PRIMARY KEY UNIQUE,
        subscription_status VARCHAR(10),
        uid VARCHAR(50),
        subscription_details JSONB,
        order_status INTEGER DEFAULT 2,
        subTotal NUMERIC,
        gst NUMERIC, 
        userdata JSONB,
        deliveryCharge NUMERIC,
        breakfast_delivery BOOLEAN,
        lunch_delivery BOOLEAN,
        dinner_delivery BOOLEAN,
        breakfast_review BOOLEAN,
        lunch_review BOOLEAN,
        dinner_review BOOLEAN,
        subscription_day_count INTEGER,
        discount VARCHAR(50),
        start_date VARCHAR(50), 
        end_date VARCHAR(50),
        sub_pause VARCHAR(50),
        pause_date VARCHAR(50) 
      );
    `;

  try {
    await tempPool.query(createSetupMealsTableQuery);
    console.log("Setupmeals table created successfully");
  } catch (error) {
    console.log("Error creating setupmeals table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

// Function to create the images table
const createImagesTable = async () => {
  const tempPool = getDatabasePool();

  const createImagesTableQuery = `
      CREATE TABLE IF NOT EXISTS images (
        id SERIAL PRIMARY KEY,
        image_url VARCHAR(255)
      );
    `;

  try {
    await tempPool.query(createImagesTableQuery);
    console.log("Images table created successfully");
  } catch (error) {
    console.log("Error creating images table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

//  admin_addon
const createFoodItemsTable = async () => {
  const tempPool = getDatabasePool();

  const createFoodItemsTableQuery = `
      CREATE TABLE IF NOT EXISTS admin_addon (
        id SERIAL PRIMARY KEY,
        status BOOLEAN,
        name VARCHAR(255),
        image_url VARCHAR(255),
        veg_type VARCHAR(50),
        type VARCHAR(50),
        ingredient VARCHAR(255),
        price NUMERIC(10, 2),
        qty INTEGER 
      );
    `;

  try {
    await tempPool.query(createFoodItemsTableQuery);
    console.log("Food items table created successfully");
  } catch (error) {
    console.log("Error creating food items table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

// addon
const createAddonTable = async () => {
  const tempPool = getDatabasePool();

  const createAddonTableQuery = `
      CREATE TABLE IF NOT EXISTS addon (
        orderId VARCHAR(25) PRIMARY KEY,
        status BOOLEAN,
        uid VARCHAR(25),
        currentTime VARCHAR(50),
        totalPricePaid NUMERIC(10, 2),
        paymentMethod VARCHAR(25),
        types JSONB,
        userdata JSONB,
        qty INT,
        subTotal NUMERIC,
        gst NUMERIC, 
        deliveryCharge NUMERIC,
        deliveryTime VARCHAR(50)
      );
    `;

  try {
    await tempPool.query(createAddonTableQuery);
    console.log("Addon table created successfully");
  } catch (error) {
    console.log("Error creating addon table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

const createDeliveryTable = async () => {
  const tempPool = getDatabasePool();

  const createDeliveryTableQuery = `
    CREATE TABLE IF NOT EXISTS delivery (
      id SERIAL PRIMARY KEY,
      uid VARCHAR(25),
      route VARCHAR(255),
      deliveryuser VARCHAR(255),
      userdata JSONB,
      deliverydata JSONB,
      status BOOLEAN,
      delivery_type VARCHAR(10), 
      order_id VARCHAR(25) UNIQUE
  );
    `;

  try {
    await tempPool.query(createDeliveryTableQuery);
    console.log("Delivery table created successfully");
  } catch (error) {
    console.log("Error creating delivery table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

const createDeliverCompleteyTable = async () => {
  const tempPool = getDatabasePool();

  const createDeliveryTableQuery = `
    CREATE TABLE IF NOT EXISTS deliverycomplete (
      id SERIAL PRIMARY KEY,
      order_id VARCHAR(25),
      uid VARCHAR(25),
      comment TEXT,
      rating VARCHAR(10),
      delivery_user VARCHAR(255),
      delivery_status BOOLEAN,
      delivery_type VARCHAR(15),
      delivery_date VARCHAR(30),
      rating_status BOOLEAN
    );
  `;

  try {
    await tempPool.query(createDeliveryTableQuery);
    console.log("Delivery complete table created successfully");
  } catch (error) {
    console.log("Error creating delivery table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

const createMenuTable = async () => {
  const tempPool = getDatabasePool();

  const createMenuTableQuery = `
      CREATE TABLE IF NOT EXISTS menu (
        id SERIAL PRIMARY KEY,
        VegType VARCHAR(25),
        menuType VARCHAR(25),
        weekType VARCHAR(25),
        menu JSONB,
        status BOOLEAN DEFAULT TRUE
      );
    `;

  try {
    await tempPool.query(createMenuTableQuery);
    console.log("Menu table created successfully");
  } catch (error) {
    console.log("Error creating menu table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};
const createDeleteUserTable = async () => {
  const tempPool = getDatabasePool();

  const createDeleteUserTableQuery = `
      CREATE TABLE IF NOT EXISTS deleteuser (
        id SERIAL PRIMARY KEY,
        PhoneNumber VARCHAR(15) UNIQUE,
        FullName VARCHAR(25),
        Reason TEXT
      );
    `;

  try {
    await tempPool.query(createDeleteUserTableQuery);
    console.log("Deleteuser table created successfully");
  } catch (error) {
    console.log("Error creating deleteuser table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};
const createUpdatePushTable = async () => {
  const tempPool = getDatabasePool();

  const createUpdatePushTableQuery = `
    CREATE TABLE IF NOT EXISTS updatepush (
      alert_id VARCHAR(25) PRIMARY KEY,
      title VARCHAR(25),
      message TEXT,
      version VARCHAR(50),
      timestamp TIMESTAMP,
      update_url VARCHAR(50),
      dismissable BOOLEAN
    );
  `;

  try {
    await tempPool.query(createUpdatePushTableQuery);
    console.log("UpdatePush table created successfully");
  } catch (error) {
    console.log("Error creating UpdatePush table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

// routes data
const routes = [
  { Anayara: "0" },
  { Chacka: "0" },
  { Eanchakkal: "0" },
  { Palkulangara: "0" },
  { Pettah: "0" },
  { Attukal: "23" },
  { Kaithamukku: "0" },
  { Karamana: "28" },
  { Manacaud: "26" },
  { Vanchiyoor: "0" },
  { Keshavadasapuram: "24" },
  { Kuravankonam: "20" },
  { Muttada: "24" },
  { Nalanchira: "24" },
  { Parottukoonam: "28" },
  { Patom: "50" },
  { PMG: "50" },
  { Kowdiar: "50" },
  { Vazhuthacud: "23" },
  { Shasthamangala: "20" },
  { Poojapura: "30" },
  { "Museum road": "50" },
  { "Ayurveda College": "50" },
  { "Bakery junction": "50" },
  { "General Hospital": "50" },
  { Overbridge: "50" },
  { Palayalam: "50" },
  { Pattor: "50" },
  { Puthenkotta: "50" },
  { Statue: "50" },
  { Thampanoor: "50" },
  { "Bapuji Nagar": "30" },
  { Kannamoola: "50" },
  { Kumarapuram: "50" },
  { Kunnukuzhy: "50" },
  { "Medical College": "27" },
  { Pothancode: "32" },
  { Puthenpalam: "50" },
  { Pogummoodu: "35" },
  { Ullor: "28" },
  { Perrurkada: "38" },
  { Ambalamukku: "32" },
  { "Prashant Nagar": "27" },
];

const createRoutesTableAndInsertData = async () => {
  const tempPool = getDatabasePool();

  const createRoutesTableQuery = `
    CREATE TABLE IF NOT EXISTS routes (
      id SERIAL PRIMARY KEY,
      route_name VARCHAR(255) NOT NULL,
      value INT NOT NULL
    );
  `;

  const checkRoutesDataQuery = `
    SELECT COUNT(*) FROM routes;
  `;

  const insertRoutesDataQuery = `
    INSERT INTO routes (route_name, value) VALUES
    ${routes
      .map((route) => {
        const [key, value] = Object.entries(route)[0];
        return `('${key}', ${value})`;
      })
      .join(", ")};
  `;

  try {
    // Start a transaction
    await tempPool.query("BEGIN");

    // Create the routes table
    await tempPool.query(createRoutesTableQuery);
    console.log("Routes table created successfully");

    // Check if the routes table already contains data
    const res = await tempPool.query(checkRoutesDataQuery);
    const count = parseInt(res.rows[0].count, 10);

    if (count === 0) {
      // Insert the data into the routes table if it is empty
      await tempPool.query(insertRoutesDataQuery);
      console.log("Routes data inserted successfully");
    } else {
      console.log("Routes data already exists, skipping insertion");
    }

    // Commit the transaction
    await tempPool.query("COMMIT");
  } catch (error) {
    // Rollback the transaction in case of error
    await tempPool.query("ROLLBACK");
    console.log("Error creating routes table or inserting data:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

const createMealPricesTable = async () => {
  const tempPool = getDatabasePool();

  const createTableQuery = `
    DO $$
    BEGIN
      -- Create the table if it doesn't exist
      CREATE TABLE IF NOT EXISTS meal_prices (
        id SERIAL PRIMARY KEY,
        meal_type VARCHAR(20) NOT NULL,
        price VARCHAR(20) NOT NULL,
        is_vegetarian BOOLEAN,
        date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT TRUE
      );

      -- Check if the table is empty
      IF NOT EXISTS (SELECT 1 FROM meal_prices LIMIT 1) THEN
        -- Insert initial data only if the table is empty
        INSERT INTO meal_prices (meal_type, price, is_vegetarian) VALUES
          ('Breakfast', 70, NULL),
          ('Lunch', 90, TRUE),
          ('Lunch', 110, FALSE),
          ('Dinner', 70, NULL);
      END IF;
    END $$;
  `;

  try {
    await tempPool.query(createTableQuery);
    console.log("Meal prices table created or verified successfully");
  } catch (error) {
    console.log("Error creating or verifying meal prices table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

module.exports = {
  createDatabase,
  getDatabasePool,
  createTable,
  createSetupMealsTable,
  createImagesTable,
  createFoodItemsTable,
  createAddonTable,
  createDeliveryTable,
  createDeliverCompleteyTable,
  createMenuTable,
  createDeleteUserTable,
  createUpdatePushTable,
  createRoutesTableAndInsertData,
  createMealPricesTable,
};
